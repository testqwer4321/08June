package com.iluwatar.model.view.controller;

import org.junit.Test;

import com.iluwatar.model.view.controller.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
