package com.iluwatar.model.view.controller;

/**
 * 
 * GiantView displays the giant
 *
 */
public class GiantView {

  public void displayGiant(GiantModel giant) {
    System.out.println(giant);
  }
}
