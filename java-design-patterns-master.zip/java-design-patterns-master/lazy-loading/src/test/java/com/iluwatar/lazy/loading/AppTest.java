package com.iluwatar.lazy.loading;

import org.junit.Test;

import com.iluwatar.lazy.loading.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
