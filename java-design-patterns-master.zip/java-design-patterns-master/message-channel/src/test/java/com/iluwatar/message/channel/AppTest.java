package com.iluwatar.message.channel;

import org.junit.Test;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() throws Exception {
    String[] args = {};
    App.main(args);
  }
}
