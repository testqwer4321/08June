package com.iluwatar.iterator;

/**
 * 
 * ItemType enumeration
 *
 */
public enum ItemType {

  ANY, WEAPON, RING, POTION

}
