package com.iluwatar.iterator;

import org.junit.Test;

import com.iluwatar.iterator.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
