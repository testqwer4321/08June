package com.iluwatar.doublechecked.locking;

import org.junit.Test;

import com.iluwatar.doublechecked.locking.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
