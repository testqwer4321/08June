package com.iluwatar.doublechecked.locking;

/**
 * 
 * Item
 *
 */
public class Item {

  private String name;
  private int level;
}
