package com.iluwatar.event.aggregator;

import org.junit.Test;

import com.iluwatar.event.aggregator.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
