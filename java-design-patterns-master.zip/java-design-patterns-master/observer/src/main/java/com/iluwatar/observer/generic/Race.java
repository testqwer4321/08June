package com.iluwatar.observer.generic;

import com.iluwatar.observer.WeatherType;

/**
 * 
 * Race
 *
 */
public interface Race extends Observer<GWeather, Race, WeatherType> {
}
