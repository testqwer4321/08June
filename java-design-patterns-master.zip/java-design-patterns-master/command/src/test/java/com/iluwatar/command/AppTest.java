package com.iluwatar.command;

import org.junit.Test;

import com.iluwatar.command.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
