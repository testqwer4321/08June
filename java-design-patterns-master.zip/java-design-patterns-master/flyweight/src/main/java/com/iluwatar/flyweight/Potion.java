package com.iluwatar.flyweight;

/**
 * 
 * Interface for Potions.
 * 
 */
public interface Potion {

  void drink();
}
