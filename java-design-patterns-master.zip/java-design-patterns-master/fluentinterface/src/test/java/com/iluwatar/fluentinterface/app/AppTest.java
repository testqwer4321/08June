package com.iluwatar.fluentinterface.app;

import org.junit.Test;

import com.iluwatar.fluentinterface.app.App;

public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
