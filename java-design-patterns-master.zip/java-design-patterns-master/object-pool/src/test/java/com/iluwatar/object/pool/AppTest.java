package com.iluwatar.object.pool;

import org.junit.Test;

import com.iluwatar.object.pool.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
