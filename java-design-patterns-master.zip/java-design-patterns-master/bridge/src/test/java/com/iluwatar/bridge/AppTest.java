package com.iluwatar.bridge;

import org.junit.Test;

import com.iluwatar.bridge.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
