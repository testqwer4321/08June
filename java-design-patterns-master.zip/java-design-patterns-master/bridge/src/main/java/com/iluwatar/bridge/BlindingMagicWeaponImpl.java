package com.iluwatar.bridge;

/**
 * 
 * BlindingMagicWeaponImpl
 *
 */
public abstract class BlindingMagicWeaponImpl extends MagicWeaponImpl {

  public abstract void blindImp();

}
