package com.iluwatar.bridge;

/**
 * 
 * SoulEatingMagicWeaponImpl
 *
 */
public abstract class SoulEatingMagicWeaponImpl extends MagicWeaponImpl {

  public abstract void eatSoulImp();

}
