package com.iluwatar.bridge;

/**
 * 
 * FlyingMagicWeaponImpl
 *
 */
public abstract class FlyingMagicWeaponImpl extends MagicWeaponImpl {

  public abstract void flyImp();

}
