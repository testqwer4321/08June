package com.iluwatar.layers;

/**
 * 
 * View interface
 *
 */
public interface View {

  void render();

}
