package com.iluwatar.layers;

import org.junit.Test;

import com.iluwatar.layers.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
