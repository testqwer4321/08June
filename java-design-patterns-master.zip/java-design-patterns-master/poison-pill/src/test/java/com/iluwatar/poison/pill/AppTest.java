package com.iluwatar.poison.pill;

import org.junit.Test;

import com.iluwatar.poison.pill.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
