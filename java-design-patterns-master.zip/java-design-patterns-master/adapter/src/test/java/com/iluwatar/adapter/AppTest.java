package com.iluwatar.adapter;

import org.junit.Test;

import com.iluwatar.adapter.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
