package com.iluwatar.chain;

import org.junit.Test;

import com.iluwatar.chain.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
