package com.iluwatar.factory.method;

/**
 * 
 * Weapon interface
 *
 */
public interface Weapon {

}
