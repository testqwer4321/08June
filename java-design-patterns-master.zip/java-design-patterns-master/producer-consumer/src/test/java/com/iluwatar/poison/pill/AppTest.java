package com.iluwatar.poison.pill;

import org.junit.Test;

import com.iluwatar.producer.consumer.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() throws Exception {
    String[] args = {};
    App.main(args);

  }
}
