package com.iluwatar.halfsynchalfasync;

import java.util.concurrent.ExecutionException;

import org.junit.Test;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() throws InterruptedException, ExecutionException {
    App.main(null);
  }
}
