Copy into workspace\.idea\runConfigurations directory, and adjust file paths for Maven tasks.

