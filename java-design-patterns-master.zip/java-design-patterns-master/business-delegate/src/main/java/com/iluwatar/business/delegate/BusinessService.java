package com.iluwatar.business.delegate;

/**
 * 
 * Interface for service implementations
 *
 */
public interface BusinessService {

  void doProcessing();
}
