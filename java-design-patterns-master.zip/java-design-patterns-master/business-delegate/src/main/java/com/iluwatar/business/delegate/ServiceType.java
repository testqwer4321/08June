package com.iluwatar.business.delegate;

/**
 * 
 * Enumeration for service types
 *
 */
public enum ServiceType {

  EJB, JMS;
}
