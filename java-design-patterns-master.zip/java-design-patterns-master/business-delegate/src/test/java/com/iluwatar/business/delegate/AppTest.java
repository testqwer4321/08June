package com.iluwatar.business.delegate;

import org.junit.Test;

import com.iluwatar.business.delegate.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
