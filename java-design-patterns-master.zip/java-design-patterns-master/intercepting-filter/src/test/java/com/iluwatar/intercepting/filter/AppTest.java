package com.iluwatar.intercepting.filter;

import org.junit.Test;

import com.iluwatar.intercepting.filter.App;

/**
 * 
 * Application test.
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
