package com.iluwatar.abstractfactory;

/**
 * 
 * Army interface
 *
 */
public interface Army {

  String getDescription();
}
