package com.iluwatar.abstractfactory;

/**
 * 
 * Castle interface
 *
 */
public interface Castle {

  String getDescription();
}
