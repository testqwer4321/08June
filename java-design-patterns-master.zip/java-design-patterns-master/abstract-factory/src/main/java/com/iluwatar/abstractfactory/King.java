package com.iluwatar.abstractfactory;

/**
 * 
 * King interface
 *
 */
public interface King {

  String getDescription();
}
