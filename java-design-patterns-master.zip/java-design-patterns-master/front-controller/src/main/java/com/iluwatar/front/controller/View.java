package com.iluwatar.front.controller;

/**
 * 
 * Views are the representations rendered for the user.
 *
 */
public interface View {

	void display();
}
