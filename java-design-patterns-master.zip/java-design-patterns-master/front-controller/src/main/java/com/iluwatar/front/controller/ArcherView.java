package com.iluwatar.front.controller;

/**
 * 
 * View for archers.
 *
 */
public class ArcherView implements View {

	@Override
	public void display() {
		System.out.println("Displaying archers");
	}
}
