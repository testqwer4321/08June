package com.iluwatar.front.controller;

/**
 * 
 * View for catapults.
 *
 */
public class CatapultView implements View {

	@Override
	public void display() {
		System.out.println("Displaying catapults");
	}
}
