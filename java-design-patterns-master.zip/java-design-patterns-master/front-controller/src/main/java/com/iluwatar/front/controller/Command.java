package com.iluwatar.front.controller;

/**
 * 
 * Commands are the intermediary between requests and views.
 *
 */
public interface Command {
	
	void process();
}
