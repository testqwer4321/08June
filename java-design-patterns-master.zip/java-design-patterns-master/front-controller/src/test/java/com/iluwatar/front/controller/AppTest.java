package com.iluwatar.front.controller;

import org.junit.Test;

import com.iluwatar.front.controller.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {
	
	@Test
	public void test() {
		String[] args = {};
		App.main(args);
	}
}
