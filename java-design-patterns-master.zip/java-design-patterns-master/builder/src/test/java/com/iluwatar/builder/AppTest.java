package com.iluwatar.builder;

import org.junit.Test;

import com.iluwatar.builder.App;

/**
 * 
 * Application test
 *
 */
public class AppTest {

  @Test
  public void test() {
    String[] args = {};
    App.main(args);
  }
}
