package com.iluwatar.dependency.injection;

/**
 * 
 * Wizard interface
 *
 */
public interface Wizard {

  void smoke();

}
