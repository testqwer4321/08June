package com.iluwatar.dependency.injection;

/**
 * 
 * OldTobyTobacco concrete {@link Tobacco} implementation
 *
 */
public class OldTobyTobacco extends Tobacco {
}
