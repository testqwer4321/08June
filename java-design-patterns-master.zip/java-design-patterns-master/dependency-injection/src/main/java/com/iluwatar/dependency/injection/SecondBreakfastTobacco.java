package com.iluwatar.dependency.injection;

/**
 * 
 * SecondBreakfastTobacco concrete {@link Tobacco} implementation
 *
 */
public class SecondBreakfastTobacco extends Tobacco {
}
