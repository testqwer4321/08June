package com.iluwatar.dependency.injection;

/**
 * 
 * RivendellTobacco concrete {@link Tobacco} implementation
 *
 */
public class RivendellTobacco extends Tobacco {
}
